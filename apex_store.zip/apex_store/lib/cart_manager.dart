import 'package:flutter/material.dart';

class CartManager with ChangeNotifier {
  final List<Map<String, String>> _items = [];

  List<Map<String, String>> get items => _items;

  int get itemCount => _items.length;

  String get totalAmount {
    double total = 0;
    for (var item in _items) {
      final price = double.tryParse(item['price']!.replaceAll(RegExp(r'[^0-9.]'), '')) ?? 0;
      total += price;
    }
    return '\$${total.toStringAsFixed(2)}';
  }

  void addItem(Map<String, String> product) {
    _items.add(product);
    notifyListeners();
  }

  void removeItem(Map<String, String> product) {
    _items.remove(product);
    notifyListeners();
  }
}