import 'package:flutter/material.dart';

class FavoritesManager with ChangeNotifier {
  final List<Map<String, String>> _favorites = [];

  List<Map<String, String>> get favorites => _favorites;

  void addFavorite(Map<String, String> product) {
    if (!_favorites.any((item) => item['id'] == product['id'])) {
      _favorites.add(product);
      notifyListeners();
    }
  }

  void removeFavorite(Map<String, String> product) {
    _favorites.removeWhere((item) => item['id'] == product['id']);
    notifyListeners();
  }

  bool isFavorite(Map<String, String> product) {
    return _favorites.any((item) => item['id'] == product['id']);
  }
}
