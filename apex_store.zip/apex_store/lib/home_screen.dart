import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'search_screen.dart';
import 'cart_manager.dart';
import 'favorite_manager.dart';
import 'shopping_cart.dart';
import 'product_section.dart';
import 'profile_screen.dart';
import 'favorite_screen.dart';


class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int selectedCategory = 0; // 0: Accessories, 1: T-Shirts, 2: Shoes
  int selectedGender = 0; // 0: Male, 1: Female, 2: Kids

  final accessoriesMen = [
  {'id':'a1',
   'name': 'Men\'s Watch',
   'price': '\$120',
   'image': 'assets/male/download.jpg'
  },
   { 'id':'a2',
     'name': 'Men\'s Watch',
     'price': '\$140',
     'image': 'assets/male/WhatsApp Image 2025-10-20 at 11.27.45 PM.jpeg'
    },
    {'id':'a3',
     'name': 'Men\'s Watch',
     'price': '\$150', 
     'image': 'assets/male/WhatsApp Image 2025-10-20 at 11.28.19 PM.jpeg'},
    {'id':'a4',
      'name': 'Men\'s Watch', 'price': '\$400', 'image': 'assets/male/WhatsApp Image 2025-10-20 at 11.29.15 PM.jpeg'},
    {'id':'a5',
      'name': 'Men\'s Watch', 'price': '\$300', 'image': 'assets/male/WhatsApp Image 2025-10-20 at 11.29.58 PM.jpeg'},
    {'id':'a6','name': 'Men\'s Watch', 'price': '\$175', 'image': 'assets/male/WhatsApp Image 2025-10-20 at 11.57.55 PM.jpeg'},
    {'id':'a7','name': 'Men\'s Watch', 'price': '\$120', 'image': 'assets/male/WhatsApp Image 2025-10-20 at 11.58.09 PM.jpeg'},
    {'id':'a8','name': 'Men\'s Watch', 'price': '\$99', 'image': 'assets/male/WhatsApp Image 2025-10-20 at 11.58.36 PM.jpeg'},
  ];

  final accessoriesWomen = [
    {'id':'a9','name': 'Women\'s Watch', 'price': '\$70', 'image': 'assets/female/WhatsApp Image 2025-10-20 at 11.29.28 PM.jpeg'},
    {'id':'a10','name': 'Women\'s Watch', 'price': '\$50', 'image': 'assets/female/WhatsApp Image 2025-10-20 at 11.29.41 PM.jpeg'},
    {'id':'a11','name': 'Women\'s Watch', 'price': '\$70', 'image': 'assets/female/WhatsApp Image 2025-10-21 at 12.57.48 AM.jpeg'},
    {'id':'a12','name': 'Women\'s Watch', 'price': '\$50', 'image': 'assets/female/WhatsApp Image 2025-10-21 at 12.58.09 AM.jpeg'},
    {'id':'a13','name': 'Women\'s Watch', 'price': '\$70', 'image': 'assets/female/WhatsApp Image 2025-10-21 at 12.58.43 AM.jpeg'},
    {'id':'a14','name': 'Women\'s Watch', 'price': '\$50', 'image': 'assets/female/WhatsApp Image 2025-10-21 at 12.58.27 AM.jpeg'},
    {'id':'a15','name': 'Women\'s Watch', 'price': '\$70', 'image': 'assets/female/WhatsApp Image 2025-10-21 at 12.57.40 AM.jpeg'},
    {'id':'a16','name': 'Women\'s Watch', 'price': '\$50', 'image': 'assets/female/WhatsApp Image 2025-10-21 at 12.57.26 AM.jpeg'},
  ];

  final accessoriesKids = [
    {'id':'a17','name': 'Kids Watch', 'price': '\$30', 'image': 'assets/kids/WhatsApp Image 2025-10-21 at 12.54.35 AM.jpeg'},
    {'id':'a18','name': 'Kids Watch', 'price': '\$20', 'image': 'assets/kids/WhatsApp Image 2025-10-21 at 12.56.44 AM.jpeg'},
    {'id':'a19','name': 'Kids Watch', 'price': '\$30', 'image': 'assets/kids/WhatsApp Image 2025-10-21 at 12.56.59 AM.jpeg'},
    {'id':'a20','name': 'Kids Watch', 'price': '\$20', 'image': 'assets/kids/WhatsApp Image 2025-10-21 at 12.56.17 AM.jpeg'},
    {'id':'a21','name': 'Kids Watch', 'price': '\$30', 'image': 'assets/kids/WhatsApp Image 2025-10-21 at 12.54.45 AM.jpeg'},
    {'id':'a22','name': 'Kids Watch', 'price': '\$20', 'image': 'assets/kids/WhatsApp Image 2025-10-21 at 12.55.08 AM.jpeg'},
  ];

final tshirtsMen = [
    {'id':'t1','name': 'Men\'s Jacket', 'price': '\$500', 'image': 'assets/male clothes/WhatsApp Image 2025-10-21 at 1.32.54 AM.jpeg'},
    {'id':'t2','name': 'Men\'s Plain T-shirt', 'price': '\$350', 'image': 'assets/male clothes/WhatsApp Image 2025-10-21 at 1.34.22 AM.jpeg'},
    {'id':'t3','name': 'Men\'s Jacket', 'price': '\$450', 'image': 'assets/male clothes/WhatsApp Image 2025-10-21 at 1.33.23 AM.jpeg'},
    {'id':'t4','name': 'Men\'s Plain T-shirt', 'price': '\$350', 'image': 'assets/male clothes/WhatsApp Image 2025-10-21 at 1.34.36 AM.jpeg'},
    {'id':'t5','name': 'Men\'s Jacket', 'price': '\$400', 'image': 'assets/male clothes/WhatsApp Image 2025-10-21 at 1.33.50 AM.jpeg'},
    {'id':'t6','name': 'Men\'s Plain T-shirt', 'price': '\$250', 'image': 'assets/male clothes/WhatsApp Image 2025-10-21 at 1.35.00 AM.jpeg'},
  ];

  final tshirtsWomen = [
    {'id':'t7','name': 'Women\'s Jacket', 'price': '\$350', 'image': 'assets/female clothes/WhatsApp Image 2025-10-21 at 1.36.00 AM.jpeg'},
    {'id':'t8','name': 'Women\'s Jacket', 'price': '\$220', 'image': 'assets/female clothes/WhatsApp Image 2025-10-21 at 1.36.09 AM.jpeg'},
    {'id':'t9','name': 'Women\'s Jacket', 'price': '\$330', 'image': 'assets/female clothes/WhatsApp Image 2025-10-21 at 1.36.27 AM.jpeg'},
    {'id':'t10','name': 'Women\'s Jacket', 'price': '\$200', 'image': 'assets/female clothes/WhatsApp Image 2025-10-21 at 1.37.50 AM.jpeg'},
  ];

  final tshirtsKids = [
    {'id':'t11','name': 'Kids Jacket', 'price': '\$18', 'image': 'assets/kids clothes/WhatsApp Image 2025-10-21 at 1.38.24 AM.jpeg'},
    {'id':'t12','name': 'Kids Jacket T-shirt', 'price': '\$12', 'image': 'assets/kids clothes/WhatsApp Image 2025-10-21 at 1.38.33 AM.jpeg'},
    {'id':'t13','name': 'Kids Jacket', 'price': '\$18', 'image': 'assets/kids clothes/WhatsApp Image 2025-10-21 at 1.39.15 AM.jpeg'},
    {'id':'t14','name': 'Kids Jacket', 'price': '\$12', 'image': 'assets/kids clothes/WhatsApp Image 2025-10-21 at 1.39.25 AM.jpeg'},
    {'id':'t15','name': 'Kids Jacket', 'price': '\$18', 'image': 'assets/kids clothes/WhatsApp Image 2025-10-21 at 1.39.48 AM.jpeg'},
    {'id':'t16','name': 'Kids Jacket', 'price': '\$12', 'image': 'assets/kids clothes/WhatsApp Image 2025-10-21 at 1.40.06 AM.jpeg'},
  ];

  final shoesMen = [
    {'id':'s1','name': 'Men\'s Running Shoes', 'price': '\$80', 'image': 'assets/male shoes/WhatsApp Image 2025-10-21 at 2.23.25 AM.jpeg'},
    {'id':'s2','name': 'Men\'s Running Shoes', 'price': '\$60', 'image': 'assets/male shoes/WhatsApp Image 2025-10-21 at 2.23.40 AM.jpeg'},
    {'id':'s3','name': 'Men\'s Casual Shoes', 'price': '\$80', 'image': 'assets/male shoes/WhatsApp Image 2025-10-21 at 2.24.11 AM.jpeg'},
  ];

  final shoesWomen = [
    {'id':'s4','name': 'Women\'s Heels', 'price': '\$90', 'image': 'assets/female shoes/WhatsApp Image 2025-10-21 at 2.24.50 AM.jpeg'},
    {'id':'s5','name': 'Women\'s Flats', 'price': '\$70', 'image': 'assets/female shoes/WhatsApp Image 2025-10-21 at 2.25.00 AM.jpeg'},
    {'id':'s6','name': 'Women\'s Flats', 'price': '\$70', 'image': 'assets/female shoes/WhatsApp Image 2025-10-21 at 2.25.13 AM.jpeg'},
    {'id':'s7','name': 'Women\'s Flats', 'price': '\$70', 'image': 'assets/female shoes/WhatsApp Image 2025-10-21 at 2.25.26 AM.jpeg'},
  ];

  final shoesKids = [
    {'id':'s8','name': 'Kids Sneakers', 'price': '\$35', 'image': 'assets/kids shoes/WhatsApp Image 2025-10-21 at 2.25.47 AM.jpeg'},
    {'id':'s9','name': 'Kids Sneakers', 'price': '\$35', 'image': 'assets/kids shoes/WhatsApp Image 2025-10-21 at 2.25.53 AM.jpeg'},
    {'id':'s10','name': 'Kids Sneakers', 'price': '\$35', 'image': 'assets/kids shoes/WhatsApp Image 2025-10-21 at 2.26.14 AM.jpeg'},
    {'id':'s11','name': 'Kids Sneakers', 'price': '\$35', 'image': 'assets/kids shoes/WhatsApp Image 2025-10-21 at 2.26.26 AM.jpeg'},
  ];

  List<Map<String, String>> getCurrentCategoryProducts() {
    switch (selectedCategory) {
      case 0:
        return selectedGender == 0 ? accessoriesMen : selectedGender == 1 ? accessoriesWomen : accessoriesKids;
      case 1:
        return selectedGender == 0 ? tshirtsMen : selectedGender == 1 ? tshirtsWomen : tshirtsKids;
      case 2:
        return selectedGender == 0 ? shoesMen : selectedGender == 1 ? shoesWomen : shoesKids;
      default:
        return [];
    }
  }

  Widget buildDrawerItem(String label, int index, IconData icon) {
    return ListTile(
      leading: Icon(icon),
      title: Text(label),
      selected: selectedCategory == index,
      selectedTileColor: Colors.grey[300],
      onTap: () {
        setState(() {
          selectedCategory = index;
        });
        Navigator.pop(context);
      },
    );
  }

  Widget genderButton(String label, int index, Color activeColor, IconData icon) {
    return ElevatedButton.icon(
      onPressed: () {
        setState(() {
          selectedGender = index;
        });
      },
      icon: Icon(icon, size: 18),
      label: Text(label),
      style: ElevatedButton.styleFrom(
        backgroundColor: selectedGender == index ? activeColor : Colors.grey[800],
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      ),
    );
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Apex.store', style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.black,
        iconTheme: IconThemeData(color: Colors.white),
        actions: [
          IconButton(
            icon: Icon(Icons.search),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => SearchScreen()),
              );
            },
          ),
          Consumer<CartManager>(
            builder: (context, cartManager, child) {
              return Stack(
                alignment: Alignment.center,
                children: [
                  IconButton(
                    icon: Icon(Icons.shopping_cart),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => Shopping_Cart()),
                      );
                    },
                  ),
                  if (cartManager.itemCount > 0)
                    Positioned(
                      right: 8,
                      top: 8,
                      child: Container(
                        padding: EdgeInsets.all(2),
                        decoration: BoxDecoration(
                          color: Colors.red,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        constraints: BoxConstraints(minWidth: 14, minHeight: 14),
                        child: Text(
                          '${cartManager.itemCount}',
                          style: TextStyle(color: Colors.white, fontSize: 8),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                ],
              );
            },
          ),
        ],
      ),
      drawer: Drawer(
        backgroundColor: Colors.white,
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [Colors.black, Colors.grey[800]!]),
              ),
              child: Text('Categories', style: TextStyle(color: Colors.white, fontSize: 24)),
            ),
            buildDrawerItem('Accessories', 0, Icons.watch),
            buildDrawerItem('T-Shirts', 1, Icons.emoji_people),
            buildDrawerItem('Shoes', 2, Icons.directions_run),
          ],
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF0F2027), Color(0xFF203A43), Color(0xFF2C5364)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  genderButton('Male', 0, Colors.blue, Icons.male),
                  SizedBox(width: 10),
                  genderButton('Female', 1, Colors.pink, Icons.female),
                  SizedBox(width: 10),
                  genderButton('Kids', 2, Colors.orange, Icons.child_care),
                ],
              ),
              Expanded(
                child: ProductSection(
                  products: getCurrentCategoryProducts(),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class MainNavigationScreen extends StatefulWidget {
  @override
  _MainNavigationScreenState createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int selectedIndex = 0;

  final List<Widget> screens = [
    HomeScreen(),
    SearchScreen(),
    Shopping_Cart(),
    FavoritesScreen(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: screens[selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: selectedIndex,
        onTap: (index) {
          setState(() {
            selectedIndex = index;
          });
        },
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.white70,
        backgroundColor: Colors.black,
        type: BottomNavigationBarType.fixed,
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.search), label: 'Search'),
          BottomNavigationBarItem(
            icon: Consumer<CartManager>(
              builder: (context, cartManager, child) {
                return Stack(
                  children: [
                    Icon(Icons.shopping_cart),
                    if (cartManager.itemCount > 0)
                      Positioned(
                        right: 0,
                        top: 0,
                        child: Container(
                          padding: EdgeInsets.all(1),
                          decoration: BoxDecoration(
                            color: Colors.red,
                            borderRadius: BorderRadius.circular(6),
                          ),
                          constraints: BoxConstraints(minWidth: 12, minHeight: 12),
                          child: Text(
                            '${cartManager.itemCount}',
                            style: TextStyle(color: Colors.white, fontSize: 8),
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ),
                  ],
                );
              },
            ),
            label: 'Cart',
          ),
          BottomNavigationBarItem(icon: Icon(Icons.favorite), label: 'Favorites'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}