import 'package:flutter/material.dart';
import 'package:apex_store/favorite_manager.dart';
import 'package:provider/provider.dart';
import 'start_screen.dart';
import 'cart_manager.dart';
import 'home_screen.dart'; 

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => CartManager()),
        ChangeNotifierProvider(create:(_)=> FavoritesManager()),
      ],
      child: MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Apex Store',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.teal,
        scaffoldBackgroundColor: Colors.white,
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.black,
          foregroundColor: Colors.white,
        ),
      ),
      home: StartScreen(), // ← دي الشاشة اللي فيها BottomNavigationBar
    );
  }
}