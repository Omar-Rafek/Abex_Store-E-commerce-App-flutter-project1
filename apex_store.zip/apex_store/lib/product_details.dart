import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'cart_manager.dart';
import 'favorite_manager.dart';

class ProductDetail extends StatefulWidget {
  final Map<String, String> product;

  const ProductDetail({Key? key, required this.product}) : super(key: key);

  @override
  State<ProductDetail> createState() => _ProductDetailState();
}

class _ProductDetailState extends State<ProductDetail> {
  int quantity = 1;

  @override
  Widget build(BuildContext context) {
    final cartManager = Provider.of<CartManager>(context, listen: false);
    final favManager = Provider.of<FavoritesManager>(context);
    final isFav = favManager.isFavorite(widget.product);

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.product['name']!, style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.black,
        iconTheme: IconThemeData(color: Colors.white),
        actions: [
          IconButton(
            icon: Icon(
              isFav ? Icons.favorite : Icons.favorite_border,
              color: isFav ? Colors.red : Colors.white,
            ),
            onPressed: () {
              setState(() {
                if (isFav) {
                  favManager.removeFavorite(widget.product);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Removed from favorites 💔')),
                  );
                } else {
                  favManager.addFavorite(widget.product);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Added to favorites ❤️')),
                  );
                }
              });
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // صورة المنتج
          SizedBox(
  height: 220,
  child: Padding(
    padding: const EdgeInsets.symmetric(vertical: 12),
    child: Image.asset(widget.product['image']!, fit: BoxFit.contain),
  ),
),

          // التفاصيل
          Expanded(
            child: Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.grey[100],
                borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // اسم وسعر المنتج
                  Text(
                    widget.product['name']!,
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 8),
                  Text(
                    widget.product['price']!,
                    style: TextStyle(fontSize: 20, color: Colors.green[700], fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 16),

                  // وصف المنتج
                  Text(
                    'This product is crafted with premium materials and designed for comfort and style. Perfect for everyday use or special occasions.',
                    style: TextStyle(fontSize: 14, color: Colors.grey[800]),
                  ),
                  SizedBox(height: 16),

                  // تقييم بالنجوم
                  Row(
                    children: List.generate(5, (index) {
                      return Icon(Icons.star, color: Colors.amber, size: 20);
                    }),
                  ),
                  SizedBox(height: 16),

                  // اختيار الكمية
                  Row(
                    children: [
                      Text('Quantity:', style: TextStyle(fontSize: 16)),
                      SizedBox(width: 10),
                      IconButton(
                        icon: Icon(Icons.remove_circle_outline),
                        onPressed: () {
                          if (quantity > 1) {
                            setState(() => quantity--);
                          }
                        },
                      ),
                      Text('$quantity', style: TextStyle(fontSize: 16)),
                      IconButton(
                        icon: Icon(Icons.add_circle_outline),
                        onPressed: () {
                          setState(() => quantity++);
                        },
                      ),
                    ],
                  ),

                  Spacer(),

                  // زر الإضافة للسلة
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      icon: Icon(Icons.shopping_cart),
                      label: Text('Add to Cart'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.black,
                        padding: EdgeInsets.symmetric(vertical: 14),
                        textStyle: TextStyle(fontSize: 16),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      onPressed: () {
                        for (int i = 0; i < quantity; i++) {
                          cartManager.addItem(widget.product);
                        }
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('Added $quantity to cart 🛒')),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}