import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'cart_manager.dart';
import 'favorite_manager.dart';
import 'product_details.dart';

class ProductSection extends StatelessWidget {
  final List<Map<String, String>> products;

  const ProductSection({Key? key, required this.products}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GridView.count(
      crossAxisCount: 2,
      padding: EdgeInsets.all(10),
      crossAxisSpacing: 10,
      mainAxisSpacing: 10,
      childAspectRatio: 0.7,
      children: products.map((product) {
        return Consumer2<CartManager, FavoritesManager>(
          builder: (context, cartManager, favManager, child) {
            final isFav = favManager.isFavorite(product);

            return Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15),
                boxShadow: [BoxShadow(color: Colors.black26, blurRadius: 8)],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  GestureDetector(
                  onTap: () {
  Navigator.push(
    context,
    MaterialPageRoute(
      builder: (context) => ProductDetail(product: product),
    ),
  );
},
                    child: ClipRRect(
                      borderRadius: BorderRadius.vertical(top: Radius.circular(15)),
                      child: AspectRatio(
                        aspectRatio: 1.1,
                        child: Image.asset(product['image']!, fit: BoxFit.cover),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 8.0, right: 8.0, top: 4.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          product['name']!,
                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                          overflow: TextOverflow.ellipsis,
                        ),
                        SizedBox(height: 4),
                        Text(
                          product['price']!,
                          style: TextStyle(color: Colors.green[700], fontWeight: FontWeight.bold, fontSize: 14),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            IconButton(
                              icon: Icon(Icons.shopping_cart_outlined, color: Colors.blue),
                              iconSize: 22,
                              padding: EdgeInsets.zero,
                              constraints: BoxConstraints(),
                              onPressed: () {
                                cartManager.addItem(product);
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text('${product['name']} added to cart! 🛒'), duration: Duration(seconds: 1)),
                                );
                              },
                            ),
                            SizedBox(width: 8),
                            IconButton(
                              icon: Icon(isFav ? Icons.favorite : Icons.favorite_border, color: Colors.red),
                              onPressed: () {
                                if (isFav) {
                                  favManager.removeFavorite(product);
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(content: Text('${product['name']} removed from Favorites 💔')),
                                  );
                                } else {
                                  favManager.addFavorite(product);
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(content: Text('${product['name']} added to Favorites ❤️')),
                                  );
                                }
                              },
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        );
      }).toList(),
    );
  }
}