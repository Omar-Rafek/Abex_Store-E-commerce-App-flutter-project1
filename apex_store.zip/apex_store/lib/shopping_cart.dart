import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'cart_manager.dart';

class Shopping_Cart extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Consumer<CartManager>(
      builder: (context, cartManager, child) {
        return Scaffold(
          appBar: AppBar(
            title: Text('Shopping Cart', style: TextStyle(color: Colors.white)),
            backgroundColor: Colors.black,
            iconTheme: IconThemeData(color: Colors.white),
          ),
          body: cartManager.itemCount == 0
              ? Center(child: Text('Your cart is empty! 🛍️', style: TextStyle(fontSize: 20, color: Colors.grey[600])))
              : Column(
                  children: [
                    Expanded(
                      child: ListView.builder(
                        itemCount: cartManager.itemCount,
                        itemBuilder: (context, index) {
                          final item = cartManager.items[index];
                          return Card(
                            margin: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                            child: ListTile(
                              leading: ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child: Image.asset(item['image']!, width: 50, height: 50, fit: BoxFit.cover),
                              ),
                              title: Text(item['name']!, style: TextStyle(fontWeight: FontWeight.bold)),
                              subtitle: Text(item['price']!),
                              trailing: IconButton(
                                icon: Icon(Icons.delete, color: Colors.red),
                                onPressed: () {
                                  cartManager.removeItem(item);
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(content: Text('${item['name']} removed from cart.'), duration: Duration(seconds: 1)),
                                  );
                                },
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 10, offset: Offset(0, -2))],
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Total (${cartManager.itemCount} items):', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                          Text(cartManager.totalAmount, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.green)),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.black,
                          minimumSize: Size(double.infinity, 50),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                        ),
                        onPressed: () {
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Proceeding to Checkout...')));
                        },
                        child: Text('Checkout', style: TextStyle(color: Colors.white, fontSize: 18)),
                      ),
                    ),
                  ],
                ),
        );
      },
    );
  }
}